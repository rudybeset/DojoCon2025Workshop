## Patch Variables:

* __cos__ ```Number```

